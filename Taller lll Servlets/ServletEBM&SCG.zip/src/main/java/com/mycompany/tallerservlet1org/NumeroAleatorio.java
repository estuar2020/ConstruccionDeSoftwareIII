package com.mycompany.tallerservlet1org;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "NumeroAleatorio", urlPatterns = {"/NumeroAleatorio"})
public class NumeroAleatorio extends HttpServlet {

   public ArrayList<Double> numeros = new ArrayList<Double>();
    
    public void init(ServletConfig config) throws ServletException{
        super.init(config);
        for(int i=0;i<10;i++){
            numeros.add(Math.random()*(1-100)+100);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        double resultado=0;
        String rn = "";
        for(int i=0;i<10;i++){
            resultado = resultado+ numeros.get(i);
        }
        
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Numeros Aleatorios(ArrayList)</title>"); 
        out.println(" <style type=\"text/css\">");
        out.println("body{text-align: center;\n" +
                    "background-color:RGB(204,255,204);}");
        out.println(" </style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<p>SUMANDOS...</p>");
        for(int i=0;i<10;i++){
            out.println(numeros.get(i));
        }
        out.println("<p>EL RESULTADO DE LA SUMA DE LOS ARRAYLIST ALEATORIOS ES:</p>");
        out.println(""+resultado+"");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}


