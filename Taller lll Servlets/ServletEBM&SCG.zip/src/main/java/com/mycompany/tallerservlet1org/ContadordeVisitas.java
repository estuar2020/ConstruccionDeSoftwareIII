package com.mycompany.tallerservlet1org;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ContadordeVisitas", urlPatterns = {"/ContadordeVisitas"})
public class ContadordeVisitas extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Integer Repeticion = 0;
        PrintWriter out = response.getWriter();
        HttpSession Msession = request.getSession();
        Repeticion = (Integer)Msession.getAttribute("Numero");
        if(Repeticion == null){
            Repeticion = 1;
        }
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Contador de Visitas</title>");
        out.println(" <style type=\"text/css\">");
        out.println("body{text-align: center;\n" +
                    "background-color:RGB(204,255,204);}");
        out.println(" </style>");
        out.println("</head>");
        out.println("<body>");
        out.println("EL SERVLET HA SIDO VISTA... "+Repeticion+"");
        out.println("</body>");
        out.println("</html>");
        Repeticion++;
        Msession.setAttribute("Numero", Repeticion);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}

