package com.mycompany.tallerservlet1org;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Hipotenusa", urlPatterns = {"/Hipotenusa"})
public class Hipotenusa extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int cateto1 = Integer.parseInt(request.getParameter("N1"));
        int cateto2 = Integer.parseInt(request.getParameter("N2"));
        double Result = Math.sqrt((Math.pow(cateto1, 2))+(Math.pow(cateto2, 2)));
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println(" <style type=\"text/css\">");
        out.println("body{text-align: center;\n" +
                    "background-color:RGB(204,255,204);}");
        out.println(" </style>");
        out.println("<title>CalcularHipotenusa</title>");            
        out.println("</head>");
        out.println("<body>");
        out.println("<p>Resultado al ingresar los dos catetos...</p>");
        out.println("<br>");
        out.println(""+ Result +"");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}